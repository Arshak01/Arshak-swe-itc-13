import React, { useState } from "react";
import ProfileUi from 'react-profile-card';

function Login() {
  const [errorMessages, setErrorMessages] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [login,setlogin] = useState("");

  const database = [
    {
      username: "samuel",
      password: "pass1",
      name:"Samuel L. Jackson",
      img:'images.jpeg',
      age:"59",
      mail:"samuel.jackson@gmail.com",
      phone: "+374 95-55-55-55"
    },
    {
      username: "angelina",
      password: "pass2",
      name:"Angelina Jolie",
      img:"images.jpeg",
      age: "50",
      mail: "angelina.jolie@gmail.com",
      phone: "+374 77-46-56-66"
    }
  ];

  const errors = {
    uname: "invalid username ",
    pass: "invalid password"
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    var { uname, pass } = document.forms[0];
    const userData = database.find((user) => user.username === uname.value);
    if (userData) {
      if (userData.password !== pass.value) {
        setErrorMessages({ name: "pass", message: errors.pass });
      } else {
        setIsSubmitted(true);
        setlogin({userData});
      }
    } else {
      setErrorMessages({ name: "uname", message: errors.uname });
    }
  };

  const renderErrorMessage = (name) =>
    name === errorMessages.name && (
      <div className="error">{errorMessages.message}</div>
    );

  const renderForm = (
    < div className = "input-container" >
      <form className="form-component" onSubmit={handleSubmit}>
        <div className="cont1" >
          <input type="text" name="uname" placeholder="Username" required />
          {renderErrorMessage("uname")}
        </div>
        < div className = "cont1" >
          <input type="password" name="pass" placeholder="Password" required />
          {renderErrorMessage("pass")}
        </div>
        <div className="button-container">
          <input className="btn" type="submit" />
        </div>
      </form>
    </div>
  );
  function addRow() {
    return (
    <div className='UserCard'>
    <div className='UserCardTop'>
      <img src={login.userData.img} />
    </div>
    <div className='UserCardBottom'>
      <h3>{login.userData.username}</h3>
      <p>Name</p>
      <h5>{login.userData.name}</h5>
      <p>email</p>
      <h5>{login.userData.mail}</h5>
      <p>Age</p>
      <h5>{login.userData.age}</h5>
      <p>Phone number</p>
      <h5>{login.userData.phone}</h5>
    </div>
  </div>
  );  
}
  return (
    <div className="app">
      <div className="login-form">
        <table id="table">
        </table>
          {isSubmitted ?  addRow() :renderForm}
      </div>
    </div>
  );
}

export default Login