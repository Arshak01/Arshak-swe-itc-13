import './App.css';
import Login from './Loginform.js'



function App() {
  return (
    <div className='App'>
        < Login />
    </div>

            )
  }


export default App;
